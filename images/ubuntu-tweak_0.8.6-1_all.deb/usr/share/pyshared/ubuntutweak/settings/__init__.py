from gsettings import GSetting
