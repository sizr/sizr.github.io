#!/usr/bin/python

print 'Hello World'
